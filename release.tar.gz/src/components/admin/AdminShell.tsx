"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

// Most z aplikacja desktopowa (tools/kalkmate-admin-desktop, preload.js):
// window.kalkmateDesktop istnieje TYLKO wewnatrz Electrona. W przegladarce
// przycisk "Programator" sie nie pokazuje — flashowanie wymaga USB na tym
// komputerze, wiec nie ma sensu poza aplikacja.
export interface DesktopFiscalConfig {
  enabled: boolean;
  host: string;
  port: number;
  encoding: "cp1250" | "iso-8859-2";
  allowFiscal: boolean;
}
export interface DesktopFiscalInfo {
  ok: boolean;
  error?: string;
  config?: DesktopFiscalConfig;
  printer?: { online: boolean; ready: boolean; fiscal?: boolean; description?: string; last_receipt?: number | null } | null;
  queue?: Record<string, number>;
  platformError?: string | null;
}

declare global {
  interface Window {
    kalkmateDesktop?: {
      isDesktop: boolean;
      openFlasher: () => void;
      // Cichy druk etykiety PDF na zapamietanej drukarce etykiet (VEVOR).
      printLabel?: (url: string) => Promise<{ ok: boolean; printer?: string; error?: string }>;
      // Agent fiskalny wbudowany w aplikację (od 1.3.0) — DesktopFiscalCard.
      fiscal?: {
        info: (refresh?: boolean) => Promise<DesktopFiscalInfo>;
        configure: (patch: Partial<DesktopFiscalConfig>) => Promise<DesktopFiscalInfo>;
      };
    };
  }
}

const navItems = [
  {
    href: "/admin",
    label: "Dashboard",
    icon: "M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-4 0a1 1 0 01-1-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 01-1 1"
  },
  {
    href: "/admin/licenses",
    label: "Generator Licencji",
    icon: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
  },
  {
    href: "/admin/coupons",
    label: "Kupony",
    icon: "M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z"
  },
  {
    href: "/admin/mailbox",
    label: "Poczta",
    icon: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
  },
  {
    href: "/admin/newsletter",
    label: "Newsletter",
    icon: "M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"
  },
  {
    href: "/admin/gemini",
    label: "OpenRouter AI",
    icon: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"
  },
  {
    href: "/admin/devices",
    label: "Urządzenia",
    icon: "M12 2a4 4 0 014 4v12a4 4 0 01-8 0V6a4 4 0 014-4zm0 14a1 1 0 100 2 1 1 0 000-2z"
  },
  {
    href: "/admin/captures",
    label: "Galeria zdjęć",
    icon: "M3 7a2 2 0 012-2h3l2-2h4l2 2h3a2 2 0 012 2v11a2 2 0 01-2 2H5a2 2 0 01-2-2V7zm9 3a4 4 0 100 8 4 4 0 000-8z"
  },
  {
    href: "/admin/users",
    label: "Użytkownicy",
    icon: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 7a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm14 14v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"
  },
  {
    href: "/admin/orders",
    label: "Zamówienia",
    icon: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
  },
  {
    href: "/admin/fiscal",
    label: "Fiskalizacja",
    icon: "M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z"
  },
  {
    href: "/admin/inventory",
    label: "Magazyn",
    icon: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
  },
  {
    href: "/admin/etykiety",
    label: "Krajalnica etykiet",
    icon: "M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2M6 14h12v8H6z"
  },
  {
    href: "/admin/remote",
    label: "Zdalna pomoc",
    icon: "M9.75 17L15 21.75V17h4a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2h4.75z"
  },
  {
    href: "/admin/backups",
    label: "Kopie bazy",
    icon: "M4 7c0-1.657 3.582-3 8-3s8 1.343 8 3M4 7v10c0 1.657 3.582 3 8 3s8-1.343 8-3V7M4 7c0 1.657 3.582 3 8 3s8-1.343 8-3M4 12c0 1.657 3.582 3 8 3s8-1.343 8-3"
  },
  {
    href: "/admin/analytics",
    label: "Analityka",
    icon: "M3 3v18h18M9 17V9m4 8V5m4 12v-4"
  },
];

export default function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isDesktop, setIsDesktop] = useState(false);

  useEffect(() => {
    setIsDesktop(!!window.kalkmateDesktop?.isDesktop);
  }, []);

  const openFlasher = () => {
    setSidebarOpen(false);
    window.kalkmateDesktop?.openFlasher();
  };

  const handleLogout = async () => {
    await fetch("/api/admin/auth", { method: "DELETE" });
    router.push("/admin/login");
  };

  const isActive = (href: string) =>
    href === "/admin" ? pathname === "/admin" : pathname.startsWith(href);

  return (
    <div className="min-h-screen bg-[#2B2D31]">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-60 bg-[#313338] border-r border-[#3F4147] z-50 transition-transform lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center gap-2 px-5 h-14 border-b border-[#3F4147]">
          <span className="text-lg font-bold text-[#E0E0E0]">KalkMate</span>
          <span className="text-xs text-[#E0E0E0]/40 bg-[#2B2D31] px-1.5 py-0.5 rounded">
            Admin
          </span>
        </div>

        <nav className="p-3 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                isActive(item.href)
                  ? "bg-[#3B82F6]/10 text-[#3B82F6]"
                  : "text-[#E0E0E0]/60 hover:text-[#E0E0E0] hover:bg-[#3F4147]/50"
              }`}
            >
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d={item.icon} />
              </svg>
              {item.label}
            </Link>
          ))}

          {isDesktop && (
            <button
              type="button"
              onClick={openFlasher}
              title="Otwiera programator kalkulatorów (USB) — dostępny tylko w aplikacji desktopowej"
              className="flex items-center gap-3 w-full px-3 py-2 mt-2 rounded-lg text-sm text-amber-300 bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 transition-colors"
            >
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M5 12h2m10 0h2M12 5v2m0 10v2M9 9h6v6H9z" />
                <rect x="4" y="4" width="16" height="16" rx="2" />
              </svg>
              Programator kalkulatorów
            </button>
          )}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-3 border-t border-[#3F4147]">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-3 py-2 rounded-lg text-sm text-[#E0E0E0]/60 hover:text-red-400 hover:bg-[#3F4147]/50 transition-colors"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" />
            </svg>
            Wyloguj się
          </button>
        </div>
      </aside>

      {/* Top bar (mobile) */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-14 bg-[#313338] border-b border-[#3F4147] z-30 flex items-center px-4">
        <button
          onClick={() => setSidebarOpen(true)}
          className="p-1.5 rounded-lg text-[#E0E0E0]/60 hover:text-[#E0E0E0] hover:bg-[#3F4147]/50"
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </button>
        <span className="ml-3 text-sm font-bold text-[#E0E0E0]">KalkMate Admin</span>
      </div>

      {/* Main content */}
      <main className="lg:ml-60 pt-14 lg:pt-0 min-h-screen">
        <div className="p-6">{children}</div>
      </main>
    </div>
  );
}
