/**
 * Furgonetka.pl API integration
 * Uses OAuth2 password grant — Basic auth(client_id:client_secret) + username/password konta.
 * Token jest cachowany w pamięci procesu i odświeżany przez refresh_token.
 */

import { randomUUID } from "crypto";

const FURGONETKA_API_URL = process.env.FURGONETKA_API_URL || "https://api.furgonetka.pl";
// Kazde zapytanie do Furgonetki ma limit czasu — bez niego zawieszone polaczenie
// blokowalo request panelu (i petle pollingu) w nieskonczonosc.
const FURGONETKA_TIMEOUT_MS = 30_000;
const timeout = () => AbortSignal.timeout(FURGONETKA_TIMEOUT_MS);
const CLIENT_ID     = process.env.FURGONETKA_CLIENT_ID     || "";
const CLIENT_SECRET = process.env.FURGONETKA_CLIENT_SECRET || "";
const USERNAME      = process.env.FURGONETKA_USERNAME       || "";
const PASSWORD      = process.env.FURGONETKA_PASSWORD       || "";

interface TokenCache {
  token: string;
  refreshToken: string;
  expiresAt: number;
}

let _tokenCache: TokenCache | null = null;

function basicAuth() {
  return Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString("base64");
}

async function _refreshToken(refreshToken: string): Promise<void> {
  const now = Date.now();
  const res = await fetch(`${FURGONETKA_API_URL}/oauth/token`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": `Basic ${basicAuth()}`,
    },
    body: new URLSearchParams({ grant_type: "refresh_token", refresh_token: refreshToken }),
    signal: timeout(),
    cache: "no-store",
  });
  if (!res.ok) throw new Error("refresh failed");
  const data = await res.json();
  if (typeof data?.access_token !== "string" || !data.access_token) throw new Error("refresh: brak access_token");
  _tokenCache = {
    token: data.access_token,
    refreshToken: data.refresh_token || refreshToken,
    expiresAt: now + (data.expires_in ?? 3600) * 1000,
  };
}

// Jedno pobieranie tokenu naraz: rownolegle requesty po wygasnieciu tokenu
// zuzywaly ten sam refresh_token (rotowany przez serwer OAuth), wiec wszystkie
// poza pierwszym konczyly sie bledem i spadaly do password grant.
let _tokenInFlight: Promise<string> | null = null;

export async function getFurgonetkaToken(): Promise<string> {
  // Token wciąż ważny
  if (_tokenCache && _tokenCache.expiresAt > Date.now() + 60_000) {
    return _tokenCache.token;
  }
  if (!_tokenInFlight) {
    _tokenInFlight = _obtainToken().finally(() => {
      _tokenInFlight = null;
    });
  }
  return _tokenInFlight;
}

async function _obtainToken(): Promise<string> {
  const now = Date.now();

  // Spróbuj refresh zanim token wygaśnie
  if (_tokenCache?.refreshToken) {
    try {
      await _refreshToken(_tokenCache.refreshToken);
      return _tokenCache!.token;
    } catch {
      _tokenCache = null; // refresh failed — fallback do password grant
    }
  }

  if (!CLIENT_ID || !CLIENT_SECRET || !USERNAME || !PASSWORD) {
    throw new Error(
      "Brak konfiguracji Furgonetka: ustaw FURGONETKA_CLIENT_ID, FURGONETKA_CLIENT_SECRET, FURGONETKA_USERNAME, FURGONETKA_PASSWORD"
    );
  }

  const res = await fetch(`${FURGONETKA_API_URL}/oauth/token`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": `Basic ${basicAuth()}`,
    },
    body: new URLSearchParams({
      grant_type: "password",
      scope: "api",
      username: USERNAME,
      password: PASSWORD,
    }),
    signal: timeout(),
    cache: "no-store",
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Furgonetka auth failed (${res.status}): ${body.slice(0, 300)}`);
  }

  const data = await res.json();
  if (typeof data?.access_token !== "string" || !data.access_token) {
    throw new Error("Furgonetka auth: odpowiedz bez access_token");
  }
  _tokenCache = {
    token: data.access_token,
    refreshToken: data.refresh_token || "",
    expiresAt: now + (data.expires_in ?? 3600) * 1000,
  };
  return _tokenCache.token;
}

export interface FurgonetkaPackageParams {
  /** Sender data (your pickup address) */
  pickup: {
    name: string;
    company?: string;
    street: string;
    postcode: string;
    city: string;
    country_code?: string;
    email?: string;
    phone?: string;
  };
  /** Receiver data (customer) */
  receiver: {
    name: string;
    company?: string;
    street: string;
    postcode: string;
    city: string;
    country_code?: string;
    email?: string;
    phone?: string;
    /** InPost paczkomat point ID */
    point?: string;
  };
  /** Furgonetka service_id - configured in Furgonetka panel */
  service_id: number;
  /** Package dimensions */
  parcels: Array<{
    weight: number;   // kg
    width?: number;   // cm
    height?: number;  // cm
    depth?: number;   // cm
  }>;
  user_reference_number?: string;
}

export interface FurgonetkaPackageResult {
  package_id: string;
  group_id?: string;
  service?: string;
  state?: string;
}

/**
 * Add a package to Furgonetka cart (state: "waiting")
 */
export async function createFurgonetkaPackage(
  params: FurgonetkaPackageParams
): Promise<FurgonetkaPackageResult> {
  const token = await getFurgonetkaToken();

  const body = {
    service_id: params.service_id,
    pickup: {
      country_code: "PL",
      ...params.pickup,
    },
    receiver: {
      country_code: "PL",
      ...params.receiver,
    },
    parcels: params.parcels,
    type: "package",
    user_reference_number: params.user_reference_number,
  };

  const res = await fetch(`${FURGONETKA_API_URL}/packages`, {
    method: "POST",
    headers: {
      "Content-Type": "application/vnd.furgonetka.v1+json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(body),
    signal: timeout(),
    cache: "no-store",
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Furgonetka create package failed (${res.status}): ${err}`);
  }

  return res.json();
}

/**
 * Order shipment (place order) and get tracking number.
 * Uses the queue-based command: PUT /create-package-command/{uuid}
 * then polls GET /create-package-command/{uuid}.
 */
export async function orderFurgonetkaShipment(packageIds: string[]): Promise<{
  uuid: string;
  status: string;
  details?: unknown;
}> {
  const token = await getFurgonetkaToken();
  const uuid = randomUUID();

  const res = await fetch(`${FURGONETKA_API_URL}/create-package-command/${uuid}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/vnd.furgonetka.v1+json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      packages: packageIds.map((id) => ({ id })),
    }),
    signal: timeout(),
    cache: "no-store",
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Furgonetka order shipment failed (${res.status}): ${err}`);
  }

  return { uuid, ...(await res.json()) };
}

/**
 * Poll create-package-command status
 */
export async function getFurgonetkaCommandStatus(uuid: string): Promise<{
  status: string;
  details?: unknown;
  errors?: unknown[];
}> {
  const token = await getFurgonetkaToken();

  const res = await fetch(`${FURGONETKA_API_URL}/create-package-command/${encodeURIComponent(uuid)}`, {
    headers: { Authorization: `Bearer ${token}` },
    signal: timeout(),
    cache: "no-store",
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Furgonetka command status failed (${res.status}): ${err}`);
  }

  return res.json();
}

/**
 * Request label document generation (async, returns uuid)
 */
export async function requestFurgonetkaDocuments(packageIds: string[]): Promise<string> {
  const token = await getFurgonetkaToken();
  const uuid = randomUUID();

  const res = await fetch(`${FURGONETKA_API_URL}/documents-command/${uuid}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/vnd.furgonetka.v1+json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      packages: packageIds.map((id) => ({ id })),
      documents_types: ["labels"],
      label: { page_format: "a4" },
    }),
    signal: timeout(),
    cache: "no-store",
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Furgonetka request documents failed (${res.status}): ${err}`);
  }

  return uuid;
}

/**
 * Poll documents command and return URL when ready
 */
export async function getFurgonetkaDocumentUrl(
  uuid: string,
  maxWaitMs = 30_000,
  pollIntervalMs = 2_000
): Promise<string> {
  const deadline = Date.now() + maxWaitMs;

  while (Date.now() < deadline) {
    // Token pobierany w kazdej iteracji (z cache) — przy dlugim pollingu moze wygasnac.
    const token = await getFurgonetkaToken();
    // Pojedyncze zapytanie nie dluzej niz pozostaly budzet (min. 5 s).
    const left = Math.max(5_000, Math.min(FURGONETKA_TIMEOUT_MS, deadline - Date.now()));
    const res = await fetch(`${FURGONETKA_API_URL}/documents-command/${encodeURIComponent(uuid)}`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(left),
      cache: "no-store",
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Furgonetka document status failed (${res.status}): ${err}`);
    }

    const data = await res.json();

    if (data.status === "done" || data.status === "completed") {
      if (!data.url) throw new Error("Furgonetka: document ready but no URL");
      return data.url;
    }

    if (data.status === "error" || data.status === "failed") {
      throw new Error(`Furgonetka document generation failed: ${JSON.stringify(data.errors)}`);
    }

    // Still processing – wait
    await new Promise((r) => setTimeout(r, pollIntervalMs));
  }

  throw new Error("Furgonetka document generation timed out");
}
