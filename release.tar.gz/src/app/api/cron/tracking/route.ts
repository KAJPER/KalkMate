import { NextRequest, NextResponse } from "next/server";
import { createHash, timingSafeEqual } from "crypto";
import { syncAllPendingOrders } from "@/lib/inpostTracking";
import { syncAllPendingBaseCourierOrders } from "@/lib/basecourierTracking";
import { cancelStaleUnpaidOrders, STALE_DAYS } from "@/lib/orderCleanup";
import { sendPaymentReminders, type ReminderResult } from "@/lib/paymentReminders";
import { ensureDailyBackup } from "@/lib/dbBackup";

// GET /api/cron/tracking — wolane co godzine z crona na serwerze
// (/home/ubuntu/kalkulator/tracking-cron.sh) z naglowkiem x-cron-secret.
// Sledzi InPost (Paczkomat, w tym Paczkomat nadany przez Base Courier) ORAZ
// przesylki zagraniczne nadane przez Base Courier innym kurierem (DPD, GLS,
// UPS...) — src/lib/basecourierTracking.ts. Oprocz tego wysyla przypomnienia
// "dokoncz platnosc" (src/lib/paymentReminders.ts) i anuluje porzucone
// zamowienia (platnosc pending starsza niz STALE_DAYS) — src/lib/orderCleanup.ts.
//
// Historia: poprzednia wersja iterowala po Stripe PaymentIntents (zamowienia
// ida dzis przez P24 -> nic nie znajdowala), odpytywala zly URL InPost
// (/trackings/ -> 404) i nigdy nie zmieniala statusu zamowienia. Teraz:
// tabela Order + src/lib/inpostTracking.ts + wspolna logika maili z panelu.

const CRON_SECRET = process.env.CRON_SECRET || "";

// Porownanie w stalym czasie (hash wyrownuje dlugosci, wiec timingSafeEqual
// nie rzuca i nie zdradza dlugosci sekretu).
function secretMatches(given: string | null): boolean {
  if (!CRON_SECRET || !given) return false;
  const a = createHash("sha256").update(given).digest();
  const b = createHash("sha256").update(CRON_SECRET).digest();
  return timingSafeEqual(a, b);
}

// Prosty mutex w pamieci procesu: cron co godzine, ale sledzenie + backup
// potrafia trwac dlugo (InPost/Base Courier) — drugie uruchomienie w trakcie
// pierwszego wyslaloby np. podwojne przypomnienia. Zabezpieczenie przed
// "wiecznym" zamkiem: po LOCK_MAX_MS zamek uznajemy za porzucony.
const LOCK_MAX_MS = 30 * 60_000;
let runningSince: number | null = null;

export async function GET(req: NextRequest) {
  // Fail-secure: brak skonfigurowanego sekretu = brak dostepu. Tylko naglowek
  // (nie URL param) — sekrety w URL trafiaja do logow nginx.
  if (!secretMatches(req.headers.get("x-cron-secret"))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (runningSince !== null && Date.now() - runningSince < LOCK_MAX_MS) {
    return NextResponse.json(
      { ok: false, error: "Poprzednie uruchomienie crona jeszcze trwa", runningSince: new Date(runningSince).toISOString() },
      { status: 409 }
    );
  }
  if (runningSince !== null) {
    console.warn(`[cron/tracking] zamek z ${new Date(runningSince).toISOString()} wyglada na porzucony — uruchamiam mimo to`);
  }
  const myRun = Date.now();
  runningSince = myRun;

  // Kazdy krok osobno: wyjatek jednego nie pomija pozostalych.
  const errors: string[] = [];
  try {
    // Kopia bazy raz na dobe (lib/dbBackup.ts) — przed reszta, niezaleznie od jej bledow.
    let backup: string | null = null;
    try {
      backup = (await ensureDailyBackup())?.name ?? null;
    } catch (e) {
      console.error("[cron/tracking] database backup failed:", e);
      backup = `ERROR: ${(e as Error).message}`;
      errors.push(`backup: ${(e as Error).message}`);
    }

    let reminders: ReminderResult = { sent: [], skipped: [], failed: [] };
    try {
      reminders = await sendPaymentReminders();
    } catch (e) {
      console.error("[cron/tracking] payment reminders failed:", e);
      errors.push(`paymentReminders: ${(e as Error).message}`);
    }

    // Najpierw porzucone zamowienia — zeby sledzenie nie odpytywalo InPost
    // o numery, ktorych i tak nie bedzie.
    let stale: Awaited<ReturnType<typeof cancelStaleUnpaidOrders>> = { cancelled: [], skippedShipped: [] };
    try {
      stale = await cancelStaleUnpaidOrders();
    } catch (e) {
      console.error("[cron/tracking] stale order cleanup failed:", e);
      errors.push(`staleCleanup: ${(e as Error).message}`);
    }

    let results: Awaited<ReturnType<typeof syncAllPendingOrders>> = [];
    try {
      results = await syncAllPendingOrders();
    } catch (e) {
      console.error("[cron/tracking] inpost sync failed:", e);
      errors.push(`inpost: ${(e as Error).message}`);
    }
    const changed = results.filter((r) => r.changed);

    let bcResults: Awaited<ReturnType<typeof syncAllPendingBaseCourierOrders>> = [];
    try {
      bcResults = await syncAllPendingBaseCourierOrders();
    } catch (e) {
      console.error("[cron/tracking] basecourier sync failed:", e);
      errors.push(`basecourier: ${(e as Error).message}`);
    }
    const bcChanged = bcResults.filter((r) => r.changed);

    const summary = {
      ok: true,
      checked: results.length,
      changed: changed.length,
      emailsSent: results.filter((r) => r.emailSent).length,
      unavailable: results.filter((r) => r.note === "inpost_unavailable").length,
      returnsFlagged: results.filter((r) => r.note === "return_flagged").length,
      changes: changed.map((r) => ({
        orderId: r.orderId,
        tracking: r.trackingNumber,
        inpost: r.inpostStatus,
        from: r.previousStatus,
        to: r.newStatus,
      })),
      basecourier: {
        checked: bcResults.length,
        changed: bcChanged.length,
        emailsSent: bcResults.filter((r) => r.emailSent).length,
        unavailable: bcResults.filter((r) => r.note === "basecourier_unavailable").length,
        returnsFlagged: bcResults.filter((r) => r.note === "return_flagged").length,
        changes: bcChanged.map((r) => ({
          orderId: r.orderId,
          blpaczkaOrderId: r.blpaczkaOrderId,
          status: r.status,
          from: r.previousStatus,
          to: r.newStatus,
        })),
      },
      paymentReminders: reminders,
      backup,
      staleUnpaid: {
        olderThanDays: STALE_DAYS,
        cancelled: stale.cancelled.map((o) => o.orderNumber),
        skippedShipped: stale.skippedShipped.map((o) => o.orderNumber),
      },
      // Kroki, ktore rzucily wyjatek (reszta wykonala sie normalnie).
      errors,
    };
    console.log(
      `[cron/tracking] checked=${summary.checked} changed=${summary.changed} emails=${summary.emailsSent} unavailable=${summary.unavailable} ` +
      `bcChecked=${summary.basecourier.checked} bcChanged=${summary.basecourier.changed} staleCancelled=${stale.cancelled.length} reminders=${reminders.sent.length}` +
      (errors.length ? ` errors=${errors.length}` : "")
    );
    return NextResponse.json(summary);
  } catch (e) {
    console.error("[cron/tracking]", e);
    return NextResponse.json({ error: (e as Error).message, errors }, { status: 500 });
  } finally {
    if (runningSince === myRun) runningSince = null;
  }
}
